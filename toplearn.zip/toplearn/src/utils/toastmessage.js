
import { toast } from 'react-toastify';


export const seccess = message => {

    toast.success(message, {
        position: "top-right",
        closeOnClick: true,
        autoClose: 3000,
        hideProgressBar: false,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
    })
};

export const error = message => {

    toast.error(message, {
        position: "top-right",
        closeOnClick: true,
        autoClose: 3000,
        hideProgressBar: false,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
    })
};
import React from "react";


const Header = () => {


    return (
        <React.Fragment>
            <div className="search-form">
                <form>

                </form>
            </div>
        </React.Fragment>
    );
};

export default Header;
